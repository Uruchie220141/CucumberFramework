package com.EDRS.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.EDRS.testbase.BaseClass;

public class UpdateProfileElements {
	
		 @FindBy(xpath = "//input[@name='firstName']")
		 public WebElement firtName;
		 
		 @FindBy(xpath = "//input[@name='lastName']")
		 public WebElement lastName;
		 
		  
		 
		 @FindBy(xpath="//*[@id=\"pageNav\"]/div[5]/a")
		 public WebElement updateProfileBtn ;
		 

		  @FindBy(xpath = "//input[@name='middleName']")
		  public WebElement middleName ;
		  
		  @FindBy(xpath = "//select[@name='suffix']")
		  public WebElement suffixDD;
		  
		  @FindBy(xpath = "//input[@name='positionTitle']")
		  public WebElement jobTitle;
		  
		  @FindBy(xpath = "//input[@name='address1']")
		  public WebElement address ; 
		  
		  @FindBy(xpath="//select[@name='country']")
		  public WebElement countryDD;
		  
		  @FindBy(xpath = "//select[@name='state']")
		  public WebElement stateDD;
		  
		  @FindBy(xpath = "//input[@name='city']")
		  public WebElement city ; 
		  
		  @FindBy (xpath = "//input[@name='zip1']")
		  public WebElement zipcode1;
		  
		  @FindBy(xpath = "//input[@name='zip2']")
		  public WebElement zipcode2;
		  
		  @FindBy(xpath = "//input[@type='submit']")
		  public WebElement saveBtn;
		  
		  @FindBy(xpath = "//td[@class='notes']")
		  public WebElement verificationMsg;
		  
		  
		  public UpdateProfileElements() {
			  
			  PageFactory.initElements(BaseClass.driver, this);
			  
		  }
		 	 
}
