package com.EDRS.testbase;

import com.EDRS.pages.DashBoardPageElement;
import com.EDRS.pages.FindCase;
import com.EDRS.pages.LoginPage;
import com.EDRS.pages.UpdateProfileElements;
import com.EDRS.pages.VeriDashboardPages;
import com.EDRS.pages.VeriLoginPage;

public class PageInitializer extends BaseClass {

	public static LoginPage loginPage;

	public static DashBoardPageElement dashboard;

	public static FindCase findCase;

	public static UpdateProfileElements updateProfile;

	public static VeriLoginPage veriLogin;

	public static VeriDashboardPages veridashboard;

	public static void Initialize() {

		loginPage = new LoginPage();
		dashboard = new DashBoardPageElement();
		findCase = new FindCase();

		updateProfile = new UpdateProfileElements();

		veriLogin = new VeriLoginPage();

		veridashboard = new VeriDashboardPages();

	}

}
