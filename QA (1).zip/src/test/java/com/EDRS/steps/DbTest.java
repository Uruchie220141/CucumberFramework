package com.EDRS.steps;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.junit.Test;

public class DbTest {
	
		 
	String dbUsername = "EDRS_RO";
	String dbPassword = "YeedReed$"; 
	String dbUrl ="//jdbc:oracle:thin:@DOH-WS-ORUAT:1526:EDRSUAT"; 
	
	
	@Test 
	public void tryConnection() throws SQLException {
		
			Connection conn = DriverManager.getConnection(dbUrl,dbUrl,dbUsername);
			
			System.out.println("DB Connection is successful");
			
	}
	

}
