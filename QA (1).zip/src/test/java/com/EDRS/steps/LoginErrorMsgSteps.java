package com.EDRS.steps;

import java.util.List;
import java.util.Map;

import com.EDRS.utils.CommonMethods;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.When;
import junit.framework.Assert;

public class LoginErrorMsgSteps extends CommonMethods {
	
	@When("user enter invalid username and password and see error message")
	public void user_enter_invalid_username_and_password_and_see_error_message(DataTable dataTable) {
	  
			 
			List<Map<String, String>> list = dataTable.asMaps();
			
				 
				 for (Map<String, String> map : list) {
					 
					 
					 sendText(loginPage.userName, map.get("UserName"));
					 sendText(loginPage.password, map.get("Password"));
					 
					 click(loginPage.loginBtn);
					 
				Assert.assertEquals(map.get("ErrorMessage"), loginPage.errMsg.getText());
				
				org.junit.Assert.assertEquals(null, null);
					 
					
				}
	}




}
