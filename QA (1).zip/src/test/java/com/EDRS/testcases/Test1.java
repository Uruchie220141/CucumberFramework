package com.EDRS.testcases;

import com.EDRS.utils.CommonMethods;
import com.EDRS.utils.ConfigsReader;

public class Test1 extends CommonMethods {

	public static void main(String[] args) {

	setUp();
		Initialize();

	sendText(veriLogin.userName, ConfigsReader.getProperty("userName"));
	sendText(veriLogin.password, ConfigsReader.getProperty("password"));
	
	jsClick(veriLogin.submitBtn);
		
	
	 wait(1);

	click(veridashboard.linkToClick);
	wait(5);
	
	click(veridashboard.chiltonHospital);
		 	

}
}
