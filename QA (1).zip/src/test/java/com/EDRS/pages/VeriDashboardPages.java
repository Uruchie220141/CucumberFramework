package com.EDRS.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.EDRS.testbase.BaseClass;
import com.EDRS.utils.CommonMethods;

public class VeriDashboardPages extends CommonMethods {

	@FindBy(xpath = "/html/body/div[3]/div[1]/div[2]/table/tbody/tr[3]/td/a")

	public WebElement linkToClick;
	
	
	
	@FindBy(xpath = "/html/body/app-root/div/div/div/app-select-profile/div/div[4]/div/a/div/h5")
	public WebElement chiltonHospital;
	
	@FindBy(xpath = "//*[@id=\"top-nav\"]/ul[1]/li[4]/a")
	public WebElement reports ;
	
	@FindBy (xpath = "/html/body/app-root/div/div/div/app-reports/div/div[2]/a[2]/div/span")
	public WebElement fetalDataByFacility;
	
	@FindBy(xpath = "//input[@class='form-control form-control-sm ng-pristine ng-invalid ng-touched']")
	public WebElement deathYear;
	
	@FindBy(id="search-btn")
	public WebElement searchClick;
	
	@FindBy(xpath = "//button[@class='btn btn-sm btn-primary dropdown-toggle']")
	public WebElement downloadBtn;
	

		 public VeriDashboardPages() {
			 
			 PageFactory.initElements(BaseClass.driver, this);
		 }
}
