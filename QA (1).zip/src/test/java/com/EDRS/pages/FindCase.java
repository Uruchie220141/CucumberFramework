package com.EDRS.pages;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.EDRS.testbase.BaseClass;

public class FindCase {
	
		
		 @FindBy(xpath="//select[@name='deathCounty']")
		 public WebElement dropDownCounty;
		 
		 @FindBy(xpath="//input[@name='firstName']")
		 public WebElement nameId;
		 
		 @FindBy (xpath = "//input[@name='ownedCases']")
		 public List<WebElement> radioBtn;
		 
		 @FindBy (xpath = "//select[@name='deathMuni']")
		 public WebElement municipalityOfDeath;
		 
		 @FindBy(xpath = "//input[@name='ownedCases']")
		 public WebElement ownedCase;
		 
		 
		 
		  public FindCase() {
			  PageFactory.initElements(BaseClass.driver, this);
		  }
}
