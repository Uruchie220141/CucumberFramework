package com.EDRS.pages;

import com.EDRS.testbase.BaseClass;
import com.EDRS.utils.CommonMethods;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage extends CommonMethods {

	@FindBy(xpath = "//input[@name='userName']")
	public WebElement userName;

	@FindBy(xpath = "//input[@name='password']")
	public WebElement password;

	@FindBy(xpath = "//input[@name='submit']")
	public WebElement loginBtn;
	
	@FindBy (xpath = "//div[@id='popupWarning']")
	public WebElement errMsg;
	

	@FindBy(xpath = "//img[@src='/edrs/images/logo_nav_no_line.jpg']")
	public WebElement logo;

	public LoginPage() {

		PageFactory.initElements(BaseClass.driver, this);

	}
	
	
	public void login(String uid , String pwd) {
		
		sendText(userName, uid);
		sendText(password, pwd);
		click(loginBtn);
			 
	}

}
