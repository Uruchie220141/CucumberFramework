package com.EDRS.steps;

import org.openqa.selenium.By;


import com.EDRS.utils.CommonMethods;
import com.EDRS.utils.ConfigsReader;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import junit.framework.Assert;

public class UpdateProfileSteps extends CommonMethods {

	@Given("user is logged as Admin Ashbrook")
	public void user_is_logged_as_admin_ashbrook() {

		loginPage.login(ConfigsReader.getProperty("userName"), ConfigsReader.getProperty("password"));

	}

	@When("user clicks on Update Profile")
	public void user_clicks_on_update_profile() {

		// wait(1);
		click(updateProfile.updateProfileBtn);

	}

	@When("user updates and saves")
	public void user_updates_and_saves() {

		// sendText(updateProfile.middleName, "Hello World");
		selectDdValue(updateProfile.suffixDD, 4);
		sendText(updateProfile.jobTitle, "QA Automation Engineer");
		sendText(updateProfile.address, "1234 Main Street");
		selectDdValue(updateProfile.countryDD, "United States");
		wait(1);
		selectDdValue(updateProfile.stateDD, "New Jersey");
		sendText(updateProfile.city, "Newark");
		sendText(updateProfile.zipcode1, "07105");
		sendText(updateProfile.zipcode2, "9299");
		jsClick(updateProfile.saveBtn);
	}

	@Then("user valides updated information saved")
	public void user_valides_updated_information_saved() {

		String expectedText = "Your EDRS profile has been updated.";

		String actualText = updateProfile.verificationMsg.getText();

		org.junit.Assert.assertEquals(expectedText, actualText);
	}

	@When("user updates {string},{string},{string},{string},{string} and {string}")
	public void user_updates_and(String fName, String MiddleName, String lName, String postion, String city,String address) {

		sendText(updateProfile.firtName, fName);
		sendText(updateProfile.middleName, MiddleName);
		sendText(updateProfile.lastName, lName);
		selectDdValue(updateProfile.suffixDD, 4);
		sendText(updateProfile.jobTitle, postion);
		sendText(updateProfile.address, address);
		selectDdValue(updateProfile.countryDD, "United States");
		selectDdValue(updateProfile.stateDD, "Phoenix");
		sendText(updateProfile.city, city);
		sendText(updateProfile.zipcode1, "07120");
		sendText(updateProfile.zipcode2, "0220");
		jsClick(updateProfile.saveBtn);

	}

	@Then("user validates updates")
	public void user_validates_updates(String name ) {

//		String expected="Ilhom Ishonkulov";	 
//		String actualText=dashboard.welcome.getText();
//		
//		
//		AssertJUnit.assertEquals("Texts doesn't match ", actualText, name);
//		

	}

}
