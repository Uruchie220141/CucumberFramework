package com.EDRS.steps;

import java.util.List;
import java.util.Map;

import com.EDRS.utils.CommonMethods;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class SigningInMultipleUsersSteps extends CommonMethods {
	
	
	@When("Users sign in with multiple credentials Click on sign in button")
	public void users_sign_in_with_multiple_credentials_click_on_sign_in_button(DataTable dataTable) {
		 
			 
		List<Map<String,String>>signMultiple=dataTable.asMaps();
		
			 
			 for (Map<String, String> map : signMultiple) {
				 
				 
				 sendText(loginPage.userName, map.get("UserName"));
				 sendText(loginPage.password, map.get("Password"));
				 
				 	 click(loginPage.loginBtn);
				 
				 	
				 
			}
			 
		
	}
	
}
