package com.EDRS.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.EDRS.testbase.BaseClass;
import com.EDRS.utils.CommonMethods;

public class VeriLoginPage extends CommonMethods {
	
	
		 @FindBy(xpath = "//button[@class='btn btn-light btn-sm']")
		 public WebElement loginBtn;
		 
		 @FindBy(xpath = "//input[@id='IDToken1']")
		 public WebElement userName;
		 
		 @FindBy(xpath = "//input[@id='IDToken2']")
		 public WebElement password;
		 
		 @FindBy(xpath = "//input[@name='Login.Submit']")
		 public WebElement submitBtn;
		 
		 
		 public VeriLoginPage() {
			 
			 PageFactory.initElements(BaseClass.driver, this);
			 
			
		}
		 

}
